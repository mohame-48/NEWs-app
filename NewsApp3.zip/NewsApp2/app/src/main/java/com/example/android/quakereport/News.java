package com.example.android.quakereport;



public class News {


    private String mTitle;
    private String mSection;
    private String mDate;
    private String mAuthor;
    private String mUrl;

    public News(String title, String section, String date, String url,String Author) {
        mTitle = title;
        mSection = section;
        mDate = date;
        mAuthor=Author;
        mUrl = url;
    }





    /**
     * Returns the title of the article
     */
    public String getTitle() {
        return mTitle;
    }

    /**
     * Returns the section name of the article.
     */
    public String getSection() {
        return mSection;
    }

    /**
     * Returns the web publication date of the article.
     */
    public String getDate() {
        return mDate;
    }

    /**
     * Returns the title of the article
     */
    public String getAuthor() {
        return mAuthor;
    }


    /**
     * Returns the website URL to find more information about the news.
     */
    public String getUrl() {
        return mUrl;
    }
}
